/**
 * Stub header for pico.h
 */

#include <stdint.h>

typedef uint32_t uint;
